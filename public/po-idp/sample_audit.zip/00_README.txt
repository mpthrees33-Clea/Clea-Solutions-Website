po-idp audit bundle — job 96473fe7989c
============================================================
document_recognized:  True
grounded_field_ratio: 1.000
overall_confidence:   1.000
errors:               0
warnings:             0
consistency_diffs:    0

Files:
  01_original.*           — input as received
  10_extraction_primary   — primary model output (with provenance)
  11_extraction_secondary — second model for self-consistency
  20_grounding.json       — per-field source-quote verification
  30_report.json          — all checks + verdicts
  40_sales_order.json     — mapped internal SO
  41_SO-*.pdf             — generated sales order PDF
  90_page_NN.png          — rendered source pages
